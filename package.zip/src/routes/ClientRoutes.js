import express from "express";
import { Client } from "../security/UserRoles.js"

const router = express.Router();

router.post('/webhook', Client, async ( req, res ) =>{

    res.status(200).json("sucesso")
})

export default router;